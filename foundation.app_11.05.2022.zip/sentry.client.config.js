// This file configures the intialization of Sentry on the browser.
// The config you add here will be used whenever a page is visited.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/

import * as Sentry from '@sentry/nextjs';

import { SENTRY_IGNORED_ERRORS } from 'lib/constants';
import { isProdOrStaging } from 'utils/helpers';

const SENTRY_DSN = process.env.NEXT_PUBLIC_SENTRY_DSN;

Sentry.init({
  dsn: SENTRY_DSN,
  // Note: if you want to override the automatic release value, do not set a
  // `release` value here - use the environment variable `SENTRY_RELEASE`, so
  // that it will also get attached to your source maps
  enabled: isProdOrStaging,
  environment: process.env.NEXT_PUBLIC_APP_ENV,
  ignoreErrors: SENTRY_IGNORED_ERRORS,
  tracesSampleRate: 1.0,
});
