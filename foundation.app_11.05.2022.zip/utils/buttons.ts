export const BUTTON_WIDTH = 240;
