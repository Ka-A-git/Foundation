export const URL = 'https://foundation.app';
export const TITLE = 'Foundation';
export const DESCRIPTION =
  'Foundation is a creative playground for artists, curators and collectors to experience the new creative economy.';
export const OG_IMAGE = 'https://foundation.app/opengraph-v2.jpg';
