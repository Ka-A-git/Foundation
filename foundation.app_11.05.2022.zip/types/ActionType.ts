export enum ActionType {
  'AcceptWelcomeScreen1.0' = 'Accept-WelcomeScreen-1.0',
}
