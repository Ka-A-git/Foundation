export enum BuyNowStatus {
  Open = 'OPEN',
  Canceled = 'CANCELED',
  Accepted = 'ACCEPTED',
  Invalidated = 'INVALIDATED',
}
