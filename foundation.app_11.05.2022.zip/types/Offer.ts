export enum OfferStatus {
  Highest = 'HIGHEST',
  Outbid = 'OUTBID',
  Expired = 'EXPIRED',
  Canceled = 'CANCELED',
  Accepted = 'ACCEPTED',
}
