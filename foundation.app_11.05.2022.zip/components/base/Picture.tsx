import { styled } from 'stitches.config';

const Picture = styled('picture', {});

export default Picture;
