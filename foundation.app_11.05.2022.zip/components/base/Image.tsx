import { styled } from 'stitches.config';

const Image = styled('img', {});

export default Image;
