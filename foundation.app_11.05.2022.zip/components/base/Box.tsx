import { styled } from 'stitches.config';

const Box = styled('div', {});

export default Box;
