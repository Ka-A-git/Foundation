import { styled } from 'stitches.config';
import Box from 'components/base/Box';

const Grid = styled(Box, { display: 'grid' });

export default Grid;
